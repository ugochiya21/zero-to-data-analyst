ZERO TO DATA ANALYST - PRACTICE FILES
DataBridge Academy

1. Unzip this folder somewhere easy to find, e.g. Documents\DataAnalysis.
   The book calls this your "practice-files folder".
2. Chapter 1: open brightmart.sql in MySQL Workbench and run it (lightning bolt).
   Check: SELECT COUNT(*) FROM brightmart.orders;  ->  13232
3. Chapter 1, Section 3B: import marketing_campaigns.csv (or run marketing_campaigns.sql).
4. Excel, Power BI and Python chapters use the files in the data folder.

Files
- brightmart.sql                      full database (8 tables after Chapter 1)
- marketing_campaigns.sql / .csv      extra table for import practice
- data/*.csv                          every table as CSV
- data/sales_flat.csv                 completed sales, one row per item sold
- data/supplier_orders_messy.csv      messy file for cleaning practice (Chapter 23)
- data/bm_online_orders.json          online-shop orders in JSON format (Chapter 28)
- data/exchange_rates_backup.json     saved exchange rates for offline API practice (Chapter 28)

All data is fictional and created for teaching.
Copyright DataBridge Academy. Free to use for personal learning and teaching.
