-- Imports marketing_campaigns.csv into the brightmart database.
-- Open in Workbench (File > Open SQL Script) and press the lightning bolt.

-- 1. Work inside the brightmart database
USE brightmart;

-- 2. If the table already exists (from an earlier try), delete it so we start clean
DROP TABLE IF EXISTS marketing_campaigns;

-- 3. Create an empty table: column name + data type for each column in the CSV
CREATE TABLE marketing_campaigns (
  campaign_id    INT PRIMARY KEY,   -- whole number, unique for every campaign
  campaign_name  VARCHAR(60),       -- text, up to 60 characters
  channel        VARCHAR(30),       -- text, e.g. Instagram, Radio
  start_date     DATE,              -- a date: YYYY-MM-DD
  end_date       DATE,
  budget_usd     INT,               -- money spent, in US dollars
  new_signups    INT                -- customers gained
);

-- 4. Put the 24 rows from the CSV into the table
INSERT INTO marketing_campaigns
  (campaign_id, campaign_name, channel, start_date, end_date, budget_usd, new_signups)
VALUES
(1, 'New Year Deals 2023', 'Flyer', '2023-01-01', '2023-01-21', 750, 746),
(2, 'Valentine Promo 2023', 'Instagram', '2023-02-01', '2023-02-28', 500, 176),
(3, 'Easter Sale 2023', 'Flyer', '2023-04-01', '2023-04-14', 2000, 599),
(4, 'Back to School 2023', 'Google Ads', '2023-09-01', '2023-09-14', 500, 524),
(5, 'Mid-Year Madness 2023', 'Radio', '2023-06-01', '2023-06-14', 500, 172),
(6, 'Independence Day Sale 2023', 'SMS', '2023-10-01', '2023-10-14', 1500, 659),
(7, 'Black Friday 2023', 'Instagram', '2023-11-01', '2023-11-28', 750, 722),
(8, 'Christmas Bonanza 2023', 'SMS', '2023-12-01', '2023-12-28', 500, 679),
(9, 'New Year Deals 2024', 'Radio', '2024-01-01', '2024-01-14', 500, 127),
(10, 'Valentine Promo 2024', 'SMS', '2024-02-01', '2024-02-21', 750, 509),
(11, 'Easter Sale 2024', 'Google Ads', '2024-04-01', '2024-04-14', 2000, 664),
(12, 'Back to School 2024', 'Flyer', '2024-09-01', '2024-09-28', 2000, 265),
(13, 'Mid-Year Madness 2024', 'Instagram', '2024-06-01', '2024-06-28', 2000, 734),
(14, 'Independence Day Sale 2024', 'Google Ads', '2024-10-01', '2024-10-14', 1000, 640),
(15, 'Black Friday 2024', 'Instagram', '2024-11-01', '2024-11-14', 2000, 713),
(16, 'Christmas Bonanza 2024', 'Google Ads', '2024-12-01', '2024-12-28', 1500, 624),
(17, 'New Year Deals 2025', 'Radio', '2025-01-01', '2025-01-21', 1000, 679),
(18, 'Valentine Promo 2025', 'Radio', '2025-02-01', '2025-02-21', 1000, 334),
(19, 'Easter Sale 2025', 'Google Ads', '2025-04-01', '2025-04-14', 750, 668),
(20, 'Back to School 2025', 'Flyer', '2025-09-01', '2025-09-21', 2000, 431),
(21, 'Mid-Year Madness 2025', 'Radio', '2025-06-01', '2025-06-28', 1000, 154),
(22, 'Independence Day Sale 2025', 'Instagram', '2025-10-01', '2025-10-21', 2000, 248),
(23, 'Black Friday 2025', 'Flyer', '2025-11-01', '2025-11-21', 750, 511),
(24, 'Christmas Bonanza 2025', 'Instagram', '2025-12-01', '2025-12-28', 500, 666);

-- 5. Check: this should show 24 rows
SELECT * FROM marketing_campaigns;
